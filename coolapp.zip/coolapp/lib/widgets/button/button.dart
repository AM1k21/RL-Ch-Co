import 'dart:html';

import 'package:flutter/material.dart';

import '../../views/rocket_league/rocket_league.dart';

class Button extends StatelessWidget {
  final String title;
  final Color color;
  final double textSize;
  final BorderStyle borderSide;
  final FontWeight fontWeight;
  const Button(
      this.title, this.color, this.textSize, this.borderSide, this.fontWeight);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: OutlinedButton(
        child: Text(title,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: textSize, fontWeight: fontWeight)),
        style: OutlinedButton.styleFrom(
          primary: color,
          side: BorderSide(color: color, style: borderSide),
        ),
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return const RocketPage();
          }));
        },
      ),
    );
  }
}
