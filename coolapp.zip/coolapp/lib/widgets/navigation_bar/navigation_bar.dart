import 'package:coolapp/widgets/button/button.dart';
import 'package:flutter/material.dart';

class Navigation_Bar extends StatelessWidget {
  const Navigation_Bar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return (Container(
        height: 100,
        child: Container(
          margin: const EdgeInsets.all(15.0),
          padding: const EdgeInsets.all(3.0),
          decoration: BoxDecoration(
              border: Border(
                  bottom: BorderSide(
                      width: 2.0, color: Color.fromARGB(255, 70, 70, 70)))),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Row(children: <Widget>[
                SizedBox(
                    height: 200, width: 200, child: Image.asset('logo.png')),
                Button('Rocket Rooks', Color.fromARGB(255, 0, 0, 0), 42,
                    BorderStyle.none, FontWeight.bold)
                // 42 bold
              ]),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  _NavBarItem('Our Trainers'),
                  SizedBox(
                    width: 60,
                  ),
                  _NavBarItem('Contact'),
                  SizedBox(
                    width: 60,
                  ),
                  _NavBarItem('About Us'),
                ],
              )
            ],
          ),
        )));
  }
}

class _NavBarItem extends StatelessWidget {
  final String title;
  const _NavBarItem(this.title);
  @override
  Widget build(BuildContext context) {
    //18
    return Button(title, Color.fromARGB(255, 0, 0, 0), 18, BorderStyle.none,
        FontWeight.normal);
  }
}
