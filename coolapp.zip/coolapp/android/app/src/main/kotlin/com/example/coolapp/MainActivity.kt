package com.example.coolapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
